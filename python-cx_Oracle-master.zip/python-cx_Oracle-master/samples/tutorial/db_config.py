user = "pythonhol"
pw = "welcome"
dsn = "localhost/orclpdb"
